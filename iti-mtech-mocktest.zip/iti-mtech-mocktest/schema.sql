-- ============================================
-- ITI to M.Tech Mock Test Module - MySQL Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS iti_mtech_app;
USE iti_mtech_app;

-- ---------- USERS ----------
CREATE TABLE users (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    education_level ENUM('ITI','DIPLOMA','BTECH','MTECH') NOT NULL,
    role            ENUM('STUDENT','ADMIN') NOT NULL DEFAULT 'STUDENT',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- TEST CATEGORIES (level-wise) ----------
CREATE TABLE test_categories (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,         -- e.g. "ITI Electrician", "B.Tech Mechanical"
    education_level ENUM('ITI','DIPLOMA','BTECH','MTECH') NOT NULL,
    description VARCHAR(255)
);

-- ---------- TESTS ----------
CREATE TABLE tests (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    category_id     BIGINT NOT NULL,
    title           VARCHAR(200) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 30,
    total_marks     INT NOT NULL DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES test_categories(id) ON DELETE CASCADE
);

-- ---------- QUESTIONS ----------
CREATE TABLE questions (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    test_id     BIGINT NOT NULL,
    question_text TEXT NOT NULL,
    marks       INT NOT NULL DEFAULT 1,
    FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
);

-- ---------- OPTIONS (4 per question, MCQ) ----------
CREATE TABLE question_options (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    question_id BIGINT NOT NULL,
    option_text VARCHAR(500) NOT NULL,
    is_correct  BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- ---------- TEST ATTEMPTS ----------
CREATE TABLE test_attempts (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT NOT NULL,
    test_id     BIGINT NOT NULL,
    started_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    submitted_at TIMESTAMP NULL,
    score       INT DEFAULT 0,
    status      ENUM('IN_PROGRESS','SUBMITTED') DEFAULT 'IN_PROGRESS',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
);

-- ---------- ANSWERS GIVEN ----------
CREATE TABLE attempt_answers (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    attempt_id      BIGINT NOT NULL,
    question_id     BIGINT NOT NULL,
    selected_option_id BIGINT NULL,
    is_correct      BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (attempt_id) REFERENCES test_attempts(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (selected_option_id) REFERENCES question_options(id) ON DELETE SET NULL
);

-- ============================================
-- SAMPLE DATA
-- ============================================

INSERT INTO test_categories (name, education_level, description) VALUES
('ITI Electrician', 'ITI', 'Core electrician trade test'),
('B.Tech Mechanical Engg', 'BTECH', 'Mechanical engineering fundamentals'),
('M.Tech CS Aptitude', 'MTECH', 'Advanced CS test for M.Tech students');

INSERT INTO tests (category_id, title, duration_minutes, total_marks) VALUES
(1, 'Electrician Basics - Set 1', 20, 10),
(2, 'Mechanics & Thermodynamics', 30, 20);

-- Questions for Test 1 (Electrician Basics)
INSERT INTO questions (test_id, question_text, marks) VALUES
(1, 'What is the SI unit of electrical resistance?', 2),
(1, 'Which device is used to measure current?', 2),
(1, 'What does AC stand for?', 2),
(1, 'Ohm''s Law relates Voltage, Current and what?', 2),
(1, 'What is the unit of electrical power?', 2);

-- Options for Q1 (id=1) -> correct: Ohm
INSERT INTO question_options (question_id, option_text, is_correct) VALUES
(1, 'Ohm', TRUE),
(1, 'Volt', FALSE),
(1, 'Ampere', FALSE),
(1, 'Watt', FALSE);

-- Options for Q2 (id=2) -> correct: Ammeter
INSERT INTO question_options (question_id, option_text, is_correct) VALUES
(2, 'Voltmeter', FALSE),
(2, 'Ammeter', TRUE),
(2, 'Ohmmeter', FALSE),
(2, 'Wattmeter', FALSE);

-- Options for Q3 (id=3) -> correct: Alternating Current
INSERT INTO question_options (question_id, option_text, is_correct) VALUES
(3, 'Alternating Current', TRUE),
(3, 'Active Current', FALSE),
(3, 'Applied Current', FALSE),
(3, 'Ambient Current', FALSE);

-- Options for Q4 (id=4) -> correct: Resistance
INSERT INTO question_options (question_id, option_text, is_correct) VALUES
(4, 'Power', FALSE),
(4, 'Resistance', TRUE),
(4, 'Frequency', FALSE),
(4, 'Energy', FALSE);

-- Options for Q5 (id=5) -> correct: Watt
INSERT INTO question_options (question_id, option_text, is_correct) VALUES
(5, 'Ohm', FALSE),
(5, 'Volt', FALSE),
(5, 'Watt', TRUE),
(5, 'Ampere', FALSE);


-- ============================================
-- E-COMMERCE MODULE (Books & Engineering Equipment)
-- ============================================

-- ---------- WALLETS (one per user, holds earnings from selling) ----------
CREATE TABLE wallets (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT NOT NULL UNIQUE,
    balance     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------- PRODUCT CATEGORIES ----------
CREATE TABLE product_categories (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,         -- e.g. "Books", "Mechanical Equipment", "Electrical Equipment"
    description VARCHAR(255)
);

-- ---------- PRODUCTS (sold by any user acting as a seller) ----------
CREATE TABLE products (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    seller_id       BIGINT NOT NULL,
    category_id     BIGINT NOT NULL,
    title           VARCHAR(200) NOT NULL,
    description     TEXT,
    price           DECIMAL(10,2) NOT NULL,
    stock_quantity  INT NOT NULL DEFAULT 1,
    condition_type  ENUM('NEW','USED') NOT NULL DEFAULT 'NEW',
    image_url       VARCHAR(500),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES product_categories(id) ON DELETE CASCADE
);

-- ---------- ORDERS (one order can contain multiple products, even from different sellers) ----------
CREATE TABLE orders (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    buyer_id        BIGINT NOT NULL,
    total_amount    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status          ENUM('PLACED','SHIPPED','DELIVERED','CANCELLED') DEFAULT 'PLACED',
    shipping_address VARCHAR(500),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------- ORDER ITEMS (line items, each tied to one product/seller) ----------
CREATE TABLE order_items (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id        BIGINT NOT NULL,
    product_id      BIGINT NOT NULL,
    seller_id       BIGINT NOT NULL,
    quantity        INT NOT NULL DEFAULT 1,
    unit_price      DECIMAL(10,2) NOT NULL,    -- price snapshot at time of purchase
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------- WALLET TRANSACTIONS (ledger: every credit/debit is logged) ----------
CREATE TABLE wallet_transactions (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    wallet_id       BIGINT NOT NULL,
    order_item_id   BIGINT NULL,
    amount          DECIMAL(10,2) NOT NULL,    -- positive = credit (earning), negative = debit (withdrawal)
    type            ENUM('SALE_CREDIT','WITHDRAWAL') NOT NULL,
    description     VARCHAR(255),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE,
    FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE SET NULL
);

-- ============================================
-- SAMPLE E-COMMERCE DATA
-- ============================================

INSERT INTO product_categories (name, description) VALUES
('Books', 'Engineering and ITI textbooks, reference guides'),
('Mechanical Equipment', 'Tools and instruments for mechanical engineering'),
('Electrical Equipment', 'Tools and instruments for electrical/electronics work'),
('Civil Equipment', 'Surveying and civil engineering tools'),
('Lab Instruments', 'General lab and workshop instruments');

-- Sample seller: reuse the first signed-up user once you have one (see README).
-- These INSERTs are illustrative only — replace seller_id with a real user id from your `users` table,
-- or simply list products through the app UI once you've signed up.


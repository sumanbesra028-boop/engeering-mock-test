package com.itimtech.app.controller;

import com.itimtech.app.dto.ShopDtos.CheckoutRequest;
import com.itimtech.app.entity.Order;
import com.itimtech.app.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shop/orders")
@CrossOrigin(origins = "*")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/checkout")
    public ResponseEntity<?> checkout(@RequestBody CheckoutRequest req) {
        try {
            return ResponseEntity.ok(orderService.checkout(req));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/buyer/{buyerId}")
    public List<Order> getOrdersForBuyer(@PathVariable Long buyerId) {
        return orderService.getOrdersForBuyer(buyerId);
    }
}

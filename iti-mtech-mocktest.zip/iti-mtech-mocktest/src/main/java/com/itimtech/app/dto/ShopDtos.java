package com.itimtech.app.dto;

import java.math.BigDecimal;
import java.util.List;

public class ShopDtos {

    public static class CreateProductRequest {
        public Long sellerId;
        public Long categoryId;
        public String title;
        public String description;
        public BigDecimal price;
        public Integer stockQuantity;
        public String conditionType; // NEW or USED
        public String imageUrl;
    }

    public static class CartLine {
        public Long productId;
        public Integer quantity;
    }

    public static class CheckoutRequest {
        public Long buyerId;
        public String shippingAddress;
        public List<CartLine> items;
    }

    public static class OrderResponse {
        public Long orderId;
        public BigDecimal totalAmount;
        public String status;
        public String message;

        public OrderResponse(Long orderId, BigDecimal totalAmount, String status, String message) {
            this.orderId = orderId;
            this.totalAmount = totalAmount;
            this.status = status;
            this.message = message;
        }
    }

    public static class WalletResponse {
        public BigDecimal balance;

        public WalletResponse(BigDecimal balance) {
            this.balance = balance;
        }
    }

    public static class WithdrawRequest {
        public Long userId;
        public BigDecimal amount;
    }
}

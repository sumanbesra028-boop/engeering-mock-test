package com.itimtech.app.service;

import com.itimtech.app.dto.ShopDtos.CreateProductRequest;
import com.itimtech.app.entity.Product;
import com.itimtech.app.entity.ProductCategory;
import com.itimtech.app.entity.User;
import com.itimtech.app.repository.ProductCategoryRepository;
import com.itimtech.app.repository.ProductRepository;
import com.itimtech.app.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final ProductCategoryRepository categoryRepository;
    private final UserRepository userRepository;

    public ProductService(ProductRepository productRepository,
                           ProductCategoryRepository categoryRepository,
                           UserRepository userRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
    }

    public List<ProductCategory> getAllCategories() {
        return categoryRepository.findAll();
    }

    public List<Product> getAllActiveProducts() {
        return productRepository.findByIsActiveTrue();
    }

    public List<Product> getProductsByCategory(Long categoryId) {
        return productRepository.findByCategoryIdAndIsActiveTrue(categoryId);
    }

    public List<Product> searchProducts(String keyword) {
        return productRepository.findByTitleContainingIgnoreCaseAndIsActiveTrue(keyword);
    }

    public List<Product> getProductsBySeller(Long sellerId) {
        return productRepository.findBySellerId(sellerId);
    }

    public Product createProduct(CreateProductRequest req) {
        if (req.price == null || req.price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Price must be greater than zero");
        }
        if (req.title == null || req.title.isBlank()) {
            throw new IllegalArgumentException("Title is required");
        }

        User seller = userRepository.findById(req.sellerId)
                .orElseThrow(() -> new IllegalArgumentException("Seller account not found"));
        ProductCategory category = categoryRepository.findById(req.categoryId)
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        Product product = new Product();
        product.setSeller(seller);
        product.setCategory(category);
        product.setTitle(req.title);
        product.setDescription(req.description);
        product.setPrice(req.price);
        product.setStockQuantity(req.stockQuantity != null ? req.stockQuantity : 1);
        product.setConditionType(
                req.conditionType != null
                        ? Product.ConditionType.valueOf(req.conditionType.toUpperCase())
                        : Product.ConditionType.NEW
        );
        product.setImageUrl(req.imageUrl);
        product.setIsActive(true);

        return productRepository.save(product);
    }

    public void deactivateProduct(Long productId, Long requesterId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));
        if (!product.getSeller().getId().equals(requesterId)) {
            throw new IllegalStateException("Only the seller can remove this listing");
        }
        product.setIsActive(false);
        productRepository.save(product);
    }
}

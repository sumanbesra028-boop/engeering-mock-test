package com.itimtech.app.repository;

import com.itimtech.app.entity.TestCategory;
import com.itimtech.app.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TestCategoryRepository extends JpaRepository<TestCategory, Long> {
    List<TestCategory> findByEducationLevel(User.EducationLevel level);
}

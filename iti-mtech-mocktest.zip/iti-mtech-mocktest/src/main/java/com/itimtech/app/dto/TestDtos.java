package com.itimtech.app.dto;

import java.util.List;

public class TestDtos {

    public static class StartAttemptRequest {
        public Long userId;
        public Long testId;
    }

    public static class SubmitAnswer {
        public Long questionId;
        public Long selectedOptionId; // can be null if skipped
    }

    public static class SubmitAttemptRequest {
        public Long attemptId;
        public List<SubmitAnswer> answers;
    }

    public static class AttemptResultResponse {
        public Long attemptId;
        public Integer score;
        public Integer totalMarks;
        public Integer correctCount;
        public Integer totalQuestions;

        public AttemptResultResponse(Long attemptId, Integer score, Integer totalMarks,
                                      Integer correctCount, Integer totalQuestions) {
            this.attemptId = attemptId;
            this.score = score;
            this.totalMarks = totalMarks;
            this.correctCount = correctCount;
            this.totalQuestions = totalQuestions;
        }
    }
}

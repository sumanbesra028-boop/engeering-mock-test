package com.itimtech.app.repository;

import com.itimtech.app.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategoryIdAndIsActiveTrue(Long categoryId);
    List<Product> findByIsActiveTrue();
    List<Product> findBySellerId(Long sellerId);
    List<Product> findByTitleContainingIgnoreCaseAndIsActiveTrue(String keyword);
}

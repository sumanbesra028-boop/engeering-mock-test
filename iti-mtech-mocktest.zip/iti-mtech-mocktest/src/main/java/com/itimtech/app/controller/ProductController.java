package com.itimtech.app.controller;

import com.itimtech.app.dto.ShopDtos.CreateProductRequest;
import com.itimtech.app.entity.Product;
import com.itimtech.app.entity.ProductCategory;
import com.itimtech.app.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shop")
@CrossOrigin(origins = "*")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/categories")
    public List<ProductCategory> getCategories() {
        return productService.getAllCategories();
    }

    @GetMapping("/products")
    public List<Product> getProducts(@RequestParam(required = false) Long categoryId,
                                      @RequestParam(required = false) String search) {
        if (search != null && !search.isBlank()) {
            return productService.searchProducts(search);
        }
        if (categoryId != null) {
            return productService.getProductsByCategory(categoryId);
        }
        return productService.getAllActiveProducts();
    }

    @GetMapping("/sellers/{sellerId}/products")
    public List<Product> getMyProducts(@PathVariable Long sellerId) {
        return productService.getProductsBySeller(sellerId);
    }

    @PostMapping("/products")
    public ResponseEntity<?> createProduct(@RequestBody CreateProductRequest req) {
        try {
            return ResponseEntity.ok(productService.createProduct(req));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/products/{productId}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long productId, @RequestParam Long sellerId) {
        try {
            productService.deactivateProduct(productId, sellerId);
            return ResponseEntity.ok(Map.of("message", "Listing removed"));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}

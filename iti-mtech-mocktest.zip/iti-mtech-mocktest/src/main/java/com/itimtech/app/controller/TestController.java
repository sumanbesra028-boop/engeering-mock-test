package com.itimtech.app.controller;

import com.itimtech.app.dto.TestDtos.*;
import com.itimtech.app.entity.*;
import com.itimtech.app.repository.TestCategoryRepository;
import com.itimtech.app.service.TestService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TestController {

    private final TestService testService;
    private final TestCategoryRepository categoryRepository;

    public TestController(TestService testService, TestCategoryRepository categoryRepository) {
        this.testService = testService;
        this.categoryRepository = categoryRepository;
    }

    // GET /api/categories?level=ITI
    @GetMapping("/categories")
    public List<TestCategory> getCategories(@RequestParam(required = false) String level) {
        if (level == null) {
            return categoryRepository.findAll();
        }
        return categoryRepository.findByEducationLevel(User.EducationLevel.valueOf(level.toUpperCase()));
    }

    // GET /api/categories/{id}/tests
    @GetMapping("/categories/{id}/tests")
    public List<Test> getTestsForCategory(@PathVariable Long id) {
        return testService.getTestsByCategory(id);
    }

    // GET /api/tests/{id}/questions  (no correct-answer data included)
    @GetMapping("/tests/{id}/questions")
    public List<Question> getQuestions(@PathVariable Long id) {
        return testService.getQuestionsForTest(id);
    }

    // POST /api/attempts/start  { userId, testId }
    @PostMapping("/attempts/start")
    public ResponseEntity<?> startAttempt(@RequestBody StartAttemptRequest req) {
        try {
            TestAttempt attempt = testService.startAttempt(req.userId, req.testId);
            return ResponseEntity.ok(Map.of(
                    "attemptId", attempt.getId(),
                    "startedAt", attempt.getStartedAt().toString()
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // POST /api/attempts/submit { attemptId, answers: [{questionId, selectedOptionId}] }
    @PostMapping("/attempts/submit")
    public ResponseEntity<?> submitAttempt(@RequestBody SubmitAttemptRequest req) {
        try {
            AttemptResultResponse result = testService.submitAttempt(req);
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}

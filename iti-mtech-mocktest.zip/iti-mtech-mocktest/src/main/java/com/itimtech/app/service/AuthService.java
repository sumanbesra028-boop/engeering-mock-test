package com.itimtech.app.service;

import com.itimtech.app.dto.AuthDtos.*;
import com.itimtech.app.entity.User;
import com.itimtech.app.repository.UserRepository;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public AuthResponse signup(SignupRequest req) {
        if (userRepository.existsByEmail(req.email)) {
            throw new IllegalArgumentException("Email already registered");
        }
        User user = new User();
        user.setName(req.name);
        user.setEmail(req.email);
        user.setPasswordHash(BCrypt.hashpw(req.password, BCrypt.gensalt()));
        user.setEducationLevel(User.EducationLevel.valueOf(req.educationLevel.toUpperCase()));
        user.setRole(User.Role.STUDENT);

        User saved = userRepository.save(user);
        return new AuthResponse(saved.getId(), saved.getName(), saved.getEmail(),
                saved.getEducationLevel().name(), "Signup successful");
    }

    public AuthResponse login(LoginRequest req) {
        User user = userRepository.findByEmail(req.email)
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));

        if (!BCrypt.checkpw(req.password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password");
        }

        return new AuthResponse(user.getId(), user.getName(), user.getEmail(),
                user.getEducationLevel().name(), "Login successful");
    }
}

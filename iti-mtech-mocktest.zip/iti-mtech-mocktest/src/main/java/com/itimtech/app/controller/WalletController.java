package com.itimtech.app.controller;

import com.itimtech.app.dto.ShopDtos.WalletResponse;
import com.itimtech.app.dto.ShopDtos.WithdrawRequest;
import com.itimtech.app.entity.User;
import com.itimtech.app.entity.Wallet;
import com.itimtech.app.repository.UserRepository;
import com.itimtech.app.service.WalletService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/shop/wallet")
@CrossOrigin(origins = "*")
public class WalletController {

    private final WalletService walletService;
    private final UserRepository userRepository;

    public WalletController(WalletService walletService, UserRepository userRepository) {
        this.walletService = walletService;
        this.userRepository = userRepository;
    }

    @GetMapping("/{userId}")
    public ResponseEntity<?> getBalance(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "User not found"));
        }
        Wallet wallet = walletService.getOrCreateWallet(user);
        return ResponseEntity.ok(new WalletResponse(wallet.getBalance()));
    }

    @PostMapping("/withdraw")
    public ResponseEntity<?> withdraw(@RequestBody WithdrawRequest req) {
        try {
            User user = userRepository.findById(req.userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
            walletService.withdraw(user, req.amount);
            return ResponseEntity.ok(Map.of("message", "Withdrawal recorded successfully"));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}

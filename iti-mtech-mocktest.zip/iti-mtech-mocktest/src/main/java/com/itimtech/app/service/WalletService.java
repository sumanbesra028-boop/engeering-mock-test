package com.itimtech.app.service;

import com.itimtech.app.entity.*;
import com.itimtech.app.repository.WalletRepository;
import com.itimtech.app.repository.WalletTransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class WalletService {

    private final WalletRepository walletRepository;
    private final WalletTransactionRepository transactionRepository;

    public WalletService(WalletRepository walletRepository,
                          WalletTransactionRepository transactionRepository) {
        this.walletRepository = walletRepository;
        this.transactionRepository = transactionRepository;
    }

    /** Every user gets a wallet lazily on first need (signup, sale, or balance check). */
    @Transactional
    public Wallet getOrCreateWallet(User user) {
        return walletRepository.findByUserId(user.getId())
                .orElseGet(() -> {
                    Wallet w = new Wallet();
                    w.setUser(user);
                    w.setBalance(BigDecimal.ZERO);
                    return walletRepository.save(w);
                });
    }

    @Transactional
    public void creditSale(User seller, OrderItem item, BigDecimal amount) {
        Wallet wallet = getOrCreateWallet(seller);
        wallet.setBalance(wallet.getBalance().add(amount));
        walletRepository.save(wallet);

        WalletTransaction tx = new WalletTransaction();
        tx.setWallet(wallet);
        tx.setOrderItem(item);
        tx.setAmount(amount);
        tx.setType(WalletTransaction.Type.SALE_CREDIT);
        tx.setDescription("Sale of: " + item.getProduct().getTitle());
        transactionRepository.save(tx);
    }

    @Transactional
    public void withdraw(User user, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        Wallet wallet = getOrCreateWallet(user);
        if (wallet.getBalance().compareTo(amount) < 0) {
            throw new IllegalStateException("Insufficient wallet balance");
        }
        wallet.setBalance(wallet.getBalance().subtract(amount));
        walletRepository.save(wallet);

        WalletTransaction tx = new WalletTransaction();
        tx.setWallet(wallet);
        tx.setAmount(amount.negate());
        tx.setType(WalletTransaction.Type.WITHDRAWAL);
        tx.setDescription("Withdrawal requested by user");
        transactionRepository.save(tx);
    }
}

package com.itimtech.app.dto;

public class AuthDtos {

    public static class SignupRequest {
        public String name;
        public String email;
        public String password;
        public String educationLevel; // ITI, DIPLOMA, BTECH, MTECH
    }

    public static class LoginRequest {
        public String email;
        public String password;
    }

    public static class AuthResponse {
        public Long userId;
        public String name;
        public String email;
        public String educationLevel;
        public String message;

        public AuthResponse(Long userId, String name, String email, String educationLevel, String message) {
            this.userId = userId;
            this.name = name;
            this.email = email;
            this.educationLevel = educationLevel;
            this.message = message;
        }
    }
}

package com.itimtech.app.service;

import com.itimtech.app.dto.TestDtos.*;
import com.itimtech.app.entity.*;
import com.itimtech.app.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class TestService {

    private final TestRepository testRepository;
    private final QuestionRepository questionRepository;
    private final QuestionOptionRepository optionRepository;
    private final TestAttemptRepository attemptRepository;
    private final AttemptAnswerRepository answerRepository;
    private final UserRepository userRepository;

    public TestService(TestRepository testRepository,
                        QuestionRepository questionRepository,
                        QuestionOptionRepository optionRepository,
                        TestAttemptRepository attemptRepository,
                        AttemptAnswerRepository answerRepository,
                        UserRepository userRepository) {
        this.testRepository = testRepository;
        this.questionRepository = questionRepository;
        this.optionRepository = optionRepository;
        this.attemptRepository = attemptRepository;
        this.answerRepository = answerRepository;
        this.userRepository = userRepository;
    }

    public List<Test> getTestsByCategory(Long categoryId) {
        return testRepository.findByCategoryId(categoryId);
    }

    public List<Question> getQuestionsForTest(Long testId) {
        // Options come along via the entity relation, but isCorrect is @JsonIgnore-d,
        // so the frontend never sees correct answers while the test is live.
        return questionRepository.findByTestId(testId);
    }

    @Transactional
    public TestAttempt startAttempt(Long userId, Long testId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        Test test = testRepository.findById(testId)
                .orElseThrow(() -> new IllegalArgumentException("Test not found"));

        TestAttempt attempt = new TestAttempt();
        attempt.setUser(user);
        attempt.setTest(test);
        attempt.setStartedAt(LocalDateTime.now());
        attempt.setStatus(TestAttempt.Status.IN_PROGRESS);
        return attemptRepository.save(attempt);
    }

    @Transactional
    public AttemptResultResponse submitAttempt(SubmitAttemptRequest req) {
        TestAttempt attempt = attemptRepository.findById(req.attemptId)
                .orElseThrow(() -> new IllegalArgumentException("Attempt not found"));

        if (attempt.getStatus() == TestAttempt.Status.SUBMITTED) {
            throw new IllegalStateException("Attempt already submitted");
        }

        List<Question> questions = questionRepository.findByTestId(attempt.getTest().getId());
        Map<Long, Question> questionById = questions.stream()
                .collect(Collectors.toMap(Question::getId, q -> q));

        int score = 0;
        int correctCount = 0;

        for (SubmitAnswer ans : req.answers) {
            Question question = questionById.get(ans.questionId);
            if (question == null) continue; // ignore answers for questions not in this test

            QuestionOption selected = null;
            boolean correct = false;

            if (ans.selectedOptionId != null) {
                selected = optionRepository.findById(ans.selectedOptionId).orElse(null);
                if (selected != null && selected.getQuestion().getId().equals(question.getId())
                        && Boolean.TRUE.equals(selected.getIsCorrect())) {
                    correct = true;
                }
            }

            if (correct) {
                score += question.getMarks();
                correctCount++;
            }

            AttemptAnswer record = new AttemptAnswer();
            record.setAttempt(attempt);
            record.setQuestion(question);
            record.setSelectedOption(selected);
            record.setIsCorrect(correct);
            answerRepository.save(record);
        }

        attempt.setScore(score);
        attempt.setStatus(TestAttempt.Status.SUBMITTED);
        attempt.setSubmittedAt(LocalDateTime.now());
        attemptRepository.save(attempt);

        return new AttemptResultResponse(
                attempt.getId(),
                score,
                attempt.getTest().getTotalMarks(),
                correctCount,
                questions.size()
        );
    }
}

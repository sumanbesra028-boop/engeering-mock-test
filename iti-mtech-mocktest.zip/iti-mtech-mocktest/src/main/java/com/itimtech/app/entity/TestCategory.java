package com.itimtech.app.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "test_categories")
public class TestCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "education_level")
    private User.EducationLevel educationLevel;

    private String description;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public User.EducationLevel getEducationLevel() { return educationLevel; }
    public void setEducationLevel(User.EducationLevel educationLevel) { this.educationLevel = educationLevel; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}

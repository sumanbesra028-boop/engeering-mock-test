package com.itimtech.app.service;

import com.itimtech.app.dto.ShopDtos.*;
import com.itimtech.app.entity.*;
import com.itimtech.app.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final WalletService walletService;

    public OrderService(OrderRepository orderRepository,
                         ProductRepository productRepository,
                         UserRepository userRepository,
                         WalletService walletService) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.walletService = walletService;
    }

    /**
     * Checkout is done entirely server-side:
     * - product prices come from the database, never trusting any price the client might send
     * - stock is checked and decremented atomically inside this transaction
     * - each line item credits that product's seller's wallet immediately (this is the
     *   "earn money by selling" mechanic)
     */
    @Transactional
    public OrderResponse checkout(CheckoutRequest req) {
        if (req.items == null || req.items.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty");
        }

        User buyer = userRepository.findById(req.buyerId)
                .orElseThrow(() -> new IllegalArgumentException("Buyer account not found"));

        Order order = new Order();
        order.setBuyer(buyer);
        order.setShippingAddress(req.shippingAddress);
        order.setStatus(Order.Status.PLACED);

        List<OrderItem> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (CartLine line : req.items) {
            if (line.quantity == null || line.quantity <= 0) {
                throw new IllegalArgumentException("Invalid quantity for product " + line.productId);
            }

            Product product = productRepository.findById(line.productId)
                    .orElseThrow(() -> new IllegalArgumentException("Product not found: " + line.productId));

            if (!Boolean.TRUE.equals(product.getIsActive())) {
                throw new IllegalStateException("Product no longer available: " + product.getTitle());
            }
            if (product.getStockQuantity() < line.quantity) {
                throw new IllegalStateException("Not enough stock for: " + product.getTitle());
            }

            // Decrement stock now, inside the same transaction
            product.setStockQuantity(product.getStockQuantity() - line.quantity);
            productRepository.save(product);

            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(product);
            item.setSeller(product.getSeller());
            item.setQuantity(line.quantity);
            item.setUnitPrice(product.getPrice()); // price snapshot from DB, not from client

            items.add(item);

            BigDecimal lineTotal = product.getPrice().multiply(BigDecimal.valueOf(line.quantity));
            total = total.add(lineTotal);
        }

        order.setItems(items);
        order.setTotalAmount(total);

        Order saved = orderRepository.save(order); // cascades to save order_items too

        // Credit each seller's wallet for their line item(s) — this is the "earn money" step.
        for (OrderItem item : saved.getItems()) {
            BigDecimal lineEarning = item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            walletService.creditSale(item.getSeller(), item, lineEarning);
        }

        return new OrderResponse(saved.getId(), saved.getTotalAmount(), saved.getStatus().name(),
                "Order placed successfully");
    }

    public List<Order> getOrdersForBuyer(Long buyerId) {
        return orderRepository.findByBuyerIdOrderByCreatedAtDesc(buyerId);
    }
}

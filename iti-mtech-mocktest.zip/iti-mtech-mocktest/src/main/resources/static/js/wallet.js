const API_BASE = "/api/shop/wallet";
const user = JSON.parse(localStorage.getItem("currentUser") || "null");

if (!user) window.location.href = "index.html";

document.getElementById("userName").textContent = user.name;
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = "index.html";
});

async function loadBalance() {
    const res = await fetch(`${API_BASE}/${user.userId}`);
    const data = await res.json();
    document.getElementById("balanceAmount").textContent = Number(data.balance).toFixed(2);
}

document.getElementById("withdrawBtn").addEventListener("click", async () => {
    const msgEl = document.getElementById("walletMsg");
    const amount = parseFloat(document.getElementById("withdrawAmount").value);

    if (!amount || amount <= 0) {
        msgEl.textContent = "Enter a valid amount.";
        msgEl.className = "form-msg error";
        return;
    }

    const res = await fetch(`${API_BASE}/withdraw`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.userId, amount })
    });
    const data = await res.json();

    if (!res.ok) {
        msgEl.textContent = data.error || "Withdrawal failed";
        msgEl.className = "form-msg error";
        return;
    }

    msgEl.textContent = "Withdrawal recorded.";
    msgEl.className = "form-msg success";
    document.getElementById("withdrawAmount").value = "";
    loadBalance();
});

loadBalance();

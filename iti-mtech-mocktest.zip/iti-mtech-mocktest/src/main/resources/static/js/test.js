const API_BASE = "/api";
const user = JSON.parse(localStorage.getItem("currentUser") || "null");
const activeAttempt = JSON.parse(sessionStorage.getItem("activeAttempt") || "null");

if (!user || !activeAttempt) {
    window.location.href = "dashboard.html";
}

document.getElementById("testTitle").textContent = activeAttempt.title;

let questions = [];
let currentIndex = 0;
// answers: { questionId: selectedOptionId }
let answers = {};
let timerInterval;
let secondsLeft = activeAttempt.durationMinutes * 60;

async function loadQuestions() {
    const res = await fetch(`${API_BASE}/tests/${activeAttempt.testId}/questions`);
    questions = await res.json();
    renderQuestion();
    startTimer();
}

function renderQuestion() {
    const q = questions[currentIndex];
    const container = document.getElementById("questionContainer");

    const optionsHtml = q.options.map(opt => {
        const selected = answers[q.id] === opt.id ? "selected" : "";
        return `
            <div class="option-item ${selected}" data-option-id="${opt.id}">
                <input type="radio" name="opt" ${answers[q.id] === opt.id ? "checked" : ""} readonly>
                <span>${opt.optionText}</span>
            </div>
        `;
    }).join("");

    container.innerHTML = `
        <h3>Q${currentIndex + 1}. ${q.questionText}</h3>
        <div class="options-list">${optionsHtml}</div>
    `;

    container.querySelectorAll(".option-item").forEach(el => {
        el.addEventListener("click", () => {
            answers[q.id] = parseInt(el.dataset.optionId);
            renderQuestion();
        });
    });

    document.getElementById("qIndicator").textContent =
        `Question ${currentIndex + 1} of ${questions.length}`;

    document.getElementById("prevBtn").disabled = currentIndex === 0;
    document.getElementById("nextBtn").disabled = currentIndex === questions.length - 1;
}

document.getElementById("prevBtn").addEventListener("click", () => {
    if (currentIndex > 0) { currentIndex--; renderQuestion(); }
});
document.getElementById("nextBtn").addEventListener("click", () => {
    if (currentIndex < questions.length - 1) { currentIndex++; renderQuestion(); }
});

function startTimer() {
    updateTimerDisplay();
    timerInterval = setInterval(() => {
        secondsLeft--;
        updateTimerDisplay();
        if (secondsLeft <= 0) {
            clearInterval(timerInterval);
            submitTest(); // auto-submit when time runs out
        }
    }, 1000);
}

function updateTimerDisplay() {
    const m = Math.floor(secondsLeft / 60).toString().padStart(2, "0");
    const s = (secondsLeft % 60).toString().padStart(2, "0");
    document.getElementById("timer").textContent = `${m}:${s}`;
}

async function submitTest() {
    clearInterval(timerInterval);

    const answerList = questions.map(q => ({
        questionId: q.id,
        selectedOptionId: answers[q.id] || null
    }));

    const res = await fetch(`${API_BASE}/attempts/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            attemptId: activeAttempt.attemptId,
            answers: answerList
        })
    });

    const result = await res.json();

    if (!res.ok) {
        alert(result.error || "Could not submit test");
        return;
    }

    sessionStorage.removeItem("activeAttempt");

    document.getElementById("resultText").innerHTML = `
        Score: <b>${result.score} / ${result.totalMarks}</b><br>
        Correct Answers: <b>${result.correctCount} / ${result.totalQuestions}</b>
    `;
    document.getElementById("resultModal").classList.remove("hidden");
}

document.getElementById("submitBtn").addEventListener("click", () => {
    if (confirm("Submit the test now?")) submitTest();
});

document.getElementById("backToDashboard").addEventListener("click", () => {
    window.location.href = "dashboard.html";
});

loadQuestions();

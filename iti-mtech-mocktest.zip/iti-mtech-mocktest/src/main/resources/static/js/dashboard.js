const API_BASE = "/api";
const user = JSON.parse(localStorage.getItem("currentUser") || "null");

if (!user) {
    window.location.href = "index.html";
}

document.getElementById("userName").textContent = `${user.name} (${user.educationLevel})`;
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = "index.html";
});

async function loadCategories() {
    const res = await fetch(`${API_BASE}/categories?level=${user.educationLevel}`);
    const categories = await res.json();

    const list = document.getElementById("categoryList");
    list.innerHTML = "";

    if (categories.length === 0) {
        list.innerHTML = `<p>No test categories available yet for your level.</p>`;
        return;
    }

    categories.forEach(cat => {
        const card = document.createElement("div");
        card.className = "info-card";
        card.innerHTML = `
            <h3>${cat.name}</h3>
            <p>${cat.description || ""}</p>
            <div class="meta">View Tests →</div>
        `;
        card.addEventListener("click", () => loadTests(cat.id, cat.name));
        list.appendChild(card);
    });
}

async function loadTests(categoryId, categoryName) {
    const res = await fetch(`${API_BASE}/categories/${categoryId}/tests`);
    const tests = await res.json();

    document.getElementById("categoryTitle").textContent = categoryName;
    document.getElementById("testSection").classList.remove("hidden");

    const list = document.getElementById("testList");
    list.innerHTML = "";

    tests.forEach(test => {
        const card = document.createElement("div");
        card.className = "info-card";
        card.innerHTML = `
            <h3>${test.title}</h3>
            <p>${test.durationMinutes} minutes · ${test.totalMarks} marks</p>
            <div class="meta">Start Test →</div>
        `;
        card.addEventListener("click", () => startTest(test.id, test.title, test.durationMinutes));
        list.appendChild(card);
    });

    document.getElementById("testSection").scrollIntoView({ behavior: "smooth" });
}

async function startTest(testId, title, durationMinutes) {
    const res = await fetch(`${API_BASE}/attempts/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.userId, testId })
    });
    const data = await res.json();

    if (!res.ok) {
        alert(data.error || "Could not start test");
        return;
    }

    // Pass everything the test page needs via sessionStorage
    sessionStorage.setItem("activeAttempt", JSON.stringify({
        attemptId: data.attemptId,
        testId,
        title,
        durationMinutes
    }));

    window.location.href = "test.html";
}

loadCategories();

const API_BASE = "/api";

// Tab switching
document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
        btn.classList.add("active");
        document.getElementById(btn.dataset.tab + "Form").classList.add("active");
    });
});

function showMsg(elId, text, type) {
    const el = document.getElementById(elId);
    el.textContent = text;
    el.className = "form-msg " + type;
}

// LOGIN
document.getElementById("loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();

        if (!res.ok) {
            showMsg("loginMsg", data.error || "Login failed", "error");
            return;
        }

        localStorage.setItem("currentUser", JSON.stringify(data));
        showMsg("loginMsg", "Login successful! Redirecting...", "success");
        setTimeout(() => window.location.href = "dashboard.html", 600);
    } catch (err) {
        showMsg("loginMsg", "Could not connect to server.", "error");
    }
});

// SIGNUP
document.getElementById("signupForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;
    const educationLevel = document.getElementById("signupLevel").value;

    try {
        const res = await fetch(`${API_BASE}/auth/signup`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password, educationLevel })
        });
        const data = await res.json();

        if (!res.ok) {
            showMsg("signupMsg", data.error || "Signup failed", "error");
            return;
        }

        showMsg("signupMsg", "Account created! Please login.", "success");
        document.querySelector('.tab-btn[data-tab="login"]').click();
        document.getElementById("loginEmail").value = email;
    } catch (err) {
        showMsg("signupMsg", "Could not connect to server.", "error");
    }
});

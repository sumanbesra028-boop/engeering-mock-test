const API_BASE = "/api/shop";
const user = JSON.parse(localStorage.getItem("currentUser") || "null");

if (!user) window.location.href = "index.html";

document.getElementById("userName").textContent = user.name;
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = "index.html";
});

async function loadCategoriesIntoForm() {
    const res = await fetch(`${API_BASE}/categories`);
    const categories = await res.json();
    const select = document.getElementById("pCategory");
    select.innerHTML = "";
    categories.forEach(cat => {
        const opt = document.createElement("option");
        opt.value = cat.id;
        opt.textContent = cat.name;
        select.appendChild(opt);
    });
}

async function loadMyListings() {
    const res = await fetch(`${API_BASE}/sellers/${user.userId}/products`);
    const products = await res.json();

    const list = document.getElementById("myListings");
    list.innerHTML = "";

    const active = products.filter(p => p.isActive);

    if (active.length === 0) {
        list.innerHTML = `<p>You haven't listed anything yet.</p>`;
        return;
    }

    active.forEach(p => {
        const card = document.createElement("div");
        card.className = "product-card";
        const imgSrc = p.imageUrl || "https://via.placeholder.com/300x140?text=No+Image";

        card.innerHTML = `
            <img src="${imgSrc}" alt="${p.title}">
            <div class="product-body">
                <span class="tag">${p.conditionType}</span>
                <h3>${p.title}</h3>
                <div class="price">₹${Number(p.price).toFixed(2)}</div>
                <p style="font-size:13px;color:var(--muted);margin:0;">Stock: ${p.stockQuantity}</p>
                <button class="remove-btn">Remove Listing</button>
            </div>
        `;
        card.querySelector(".remove-btn").addEventListener("click", () => removeListing(p.id));
        list.appendChild(card);
    });
}

async function removeListing(productId) {
    if (!confirm("Remove this listing?")) return;
    const res = await fetch(`${API_BASE}/products/${productId}?sellerId=${user.userId}`, {
        method: "DELETE"
    });
    if (res.ok) loadMyListings();
}

document.getElementById("productForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById("listMsg");

    const payload = {
        sellerId: user.userId,
        categoryId: parseInt(document.getElementById("pCategory").value),
        title: document.getElementById("pTitle").value.trim(),
        description: document.getElementById("pDescription").value.trim(),
        price: parseFloat(document.getElementById("pPrice").value),
        stockQuantity: parseInt(document.getElementById("pStock").value),
        conditionType: document.getElementById("pCondition").value,
        imageUrl: document.getElementById("pImageUrl").value.trim() || null
    };

    const res = await fetch(`${API_BASE}/products`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (!res.ok) {
        msgEl.textContent = data.error || "Could not create listing";
        msgEl.className = "form-msg error";
        return;
    }

    msgEl.textContent = "Listed successfully!";
    msgEl.className = "form-msg success";
    document.getElementById("productForm").reset();
    loadMyListings();
});

loadCategoriesIntoForm();
loadMyListings();

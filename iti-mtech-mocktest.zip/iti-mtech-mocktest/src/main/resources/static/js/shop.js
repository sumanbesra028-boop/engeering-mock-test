const API_BASE = "/api/shop";
const user = JSON.parse(localStorage.getItem("currentUser") || "null");

if (!user) window.location.href = "index.html";

document.getElementById("userName").textContent = user.name;
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = "index.html";
});

// Cart lives in sessionStorage as { productId: { product, quantity } }
let cart = JSON.parse(sessionStorage.getItem("cart") || "{}");

function saveCart() {
    sessionStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
}

function updateCartCount() {
    const count = Object.values(cart).reduce((sum, line) => sum + line.quantity, 0);
    document.getElementById("cartCount").textContent = count;
}

async function loadCategories() {
    const res = await fetch(`${API_BASE}/categories`);
    const categories = await res.json();
    const select = document.getElementById("categoryFilter");
    categories.forEach(cat => {
        const opt = document.createElement("option");
        opt.value = cat.id;
        opt.textContent = cat.name;
        select.appendChild(opt);
    });
}

async function loadProducts() {
    const categoryId = document.getElementById("categoryFilter").value;
    const search = document.getElementById("searchBox").value.trim();

    let url = `${API_BASE}/products?`;
    if (search) url += `search=${encodeURIComponent(search)}`;
    else if (categoryId) url += `categoryId=${categoryId}`;

    const res = await fetch(url);
    const products = await res.json();

    const list = document.getElementById("productList");
    list.innerHTML = "";

    if (products.length === 0) {
        list.innerHTML = `<p>No products found.</p>`;
        return;
    }

    products.forEach(p => {
        const card = document.createElement("div");
        card.className = "product-card";
        const imgSrc = p.imageUrl || "https://via.placeholder.com/300x140?text=No+Image";
        const outOfStock = p.stockQuantity <= 0;

        card.innerHTML = `
            <img src="${imgSrc}" alt="${p.title}">
            <div class="product-body">
                <span class="tag">${p.conditionType}</span>
                <h3>${p.title}</h3>
                <div class="price">₹${Number(p.price).toFixed(2)}</div>
                <button class="add-cart-btn" ${outOfStock ? "disabled" : ""}>
                    ${outOfStock ? "Out of Stock" : "Add to Cart"}
                </button>
            </div>
        `;

        if (!outOfStock) {
            card.querySelector(".add-cart-btn").addEventListener("click", () => addToCart(p));
        }

        list.appendChild(card);
    });
}

function addToCart(product) {
    const key = product.id;
    if (cart[key]) {
        cart[key].quantity += 1;
    } else {
        cart[key] = { product, quantity: 1 };
    }
    saveCart();
    renderCart();
}

function renderCart() {
    const container = document.getElementById("cartItems");
    container.innerHTML = "";
    let total = 0;

    Object.entries(cart).forEach(([id, line]) => {
        const lineTotal = line.product.price * line.quantity;
        total += lineTotal;

        const row = document.createElement("div");
        row.className = "cart-line";
        row.innerHTML = `
            <span>${line.product.title} × ${line.quantity}</span>
            <span>₹${lineTotal.toFixed(2)} <button data-id="${id}">✕</button></span>
        `;
        row.querySelector("button").addEventListener("click", () => {
            delete cart[id];
            saveCart();
            renderCart();
        });
        container.appendChild(row);
    });

    document.getElementById("cartTotal").textContent = total.toFixed(2);
}

document.getElementById("cartBtn").addEventListener("click", () => {
    renderCart();
    document.getElementById("cartDrawer").classList.remove("hidden");
});
document.getElementById("closeCart").addEventListener("click", () => {
    document.getElementById("cartDrawer").classList.add("hidden");
});

document.getElementById("checkoutBtn").addEventListener("click", async () => {
    const msgEl = document.getElementById("checkoutMsg");
    const items = Object.entries(cart).map(([id, line]) => ({
        productId: parseInt(id),
        quantity: line.quantity
    }));

    if (items.length === 0) {
        msgEl.textContent = "Your cart is empty.";
        msgEl.className = "form-msg error";
        return;
    }

    const shippingAddress = document.getElementById("shippingAddress").value.trim();
    if (!shippingAddress) {
        msgEl.textContent = "Please enter a shipping address.";
        msgEl.className = "form-msg error";
        return;
    }

    const res = await fetch(`${API_BASE}/orders/checkout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ buyerId: user.userId, shippingAddress, items })
    });
    const data = await res.json();

    if (!res.ok) {
        msgEl.textContent = data.error || "Checkout failed";
        msgEl.className = "form-msg error";
        return;
    }

    msgEl.textContent = `Order placed! Total ₹${data.totalAmount}`;
    msgEl.className = "form-msg success";
    cart = {};
    saveCart();
    setTimeout(() => {
        document.getElementById("cartDrawer").classList.add("hidden");
        loadProducts(); // refresh stock numbers
    }, 1200);
});

document.getElementById("searchBox").addEventListener("input", debounce(loadProducts, 400));
document.getElementById("categoryFilter").addEventListener("change", loadProducts);

function debounce(fn, delay) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}

updateCartCount();
loadCategories();
loadProducts();

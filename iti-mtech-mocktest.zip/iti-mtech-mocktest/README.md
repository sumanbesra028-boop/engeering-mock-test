# ITI to M.Tech — Mock Test + E-Commerce Platform

Two working modules sharing one login: mock tests with server-side scoring,
and a marketplace where any logged-in user can sell books/engineering
equipment and earn money into a wallet. Built with Spring Boot (Java) +
MySQL + vanilla HTML/CSS/JS.

## What's included
- `schema.sql` — full MySQL database (run this first)
- `src/main/java/...` — Spring Boot REST API (mock tests + shop)
- `src/main/resources/static/...` — frontend (served by Spring Boot itself)

## Prerequisites
1. **Java JDK 17+** — check with `java -version`
2. **Maven** — check with `mvn -version` (or use an IDE that bundles it: IntelliJ, Eclipse, VS Code + Java extensions)
3. **MySQL Server** (via XAMPP/WAMP or standalone) — check with `mysql --version`

## Setup steps

### 1. Create the database
```bash
mysql -u root -p < schema.sql
```
This creates `iti_mtech_app` with all tables for both modules, plus sample
mock-test data (ITI Electrician, B.Tech Mechanics) and 5 product categories
(Books, Mechanical/Electrical/Civil Equipment, Lab Instruments).

### 2. Configure the database password
Edit `src/main/resources/application.properties`:
```
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

### 3. Run the app
```bash
mvn spring-boot:run
```
Or run `AppApplication.java` directly from your IDE.

The app starts on **http://localhost:8080**

### 4. Use it
1. Open `http://localhost:8080` → Sign Up (any education level)
2. **Mock Tests** tab: browse categories for your level, take a timed test, get an instant score
3. **Shop** tab: browse/search books & equipment, add to cart, checkout
4. **Sell Items** tab: list your own books/equipment for sale — anyone can become a seller
5. **My Wallet** tab: see your balance grow whenever someone buys what you listed; withdraw anytime

## How mock-test scoring works
The browser never receives which option is correct (`@JsonIgnore` on
`QuestionOption.isCorrect`). The client only sends which option ID was
picked; Java compares that against MySQL and computes the score itself.

## How the e-commerce / earnings flow works
- **Price and stock are always read from the database at checkout**, never
  trusted from the browser — a tampered request can't get a free or
  wrong-priced item.
- Checkout is wrapped in a single database transaction: if any item in the
  cart is out of stock, the *entire* order rolls back, so stock numbers
  never end up partially decremented.
- The moment an order is placed, each line item credits that product's
  seller's wallet (`WalletService.creditSale`) — this is the "earn money by
  selling" mechanic. Every credit and withdrawal is logged in
  `wallet_transactions` as a permanent ledger.
- **Withdrawal records the transaction but does not move real money.**
  There's no payment gateway wired in (Razorpay/Stripe/UPI all require a
  registered merchant account and KYC, which I can't set up on your behalf).
  The ledger logic is real and ready — plug a gateway's payout API into
  `WalletService.withdraw()` when you're ready to go live.

## Adding your own mock-test questions
Insert directly into MySQL, following the pattern in `schema.sql`:
```sql
INSERT INTO tests (category_id, title, duration_minutes, total_marks) VALUES (1, 'New Test', 20, 10);
INSERT INTO questions (test_id, question_text, marks) VALUES (3, 'Your question?', 2);
INSERT INTO question_options (question_id, option_text, is_correct) VALUES
  (6, 'Option A', FALSE), (6, 'Option B', TRUE), (6, 'Option C', FALSE), (6, 'Option D', FALSE);
```
(Check actual auto-increment IDs with `SELECT * FROM tests;` first.)

## API reference

### Auth
| Method | Endpoint           | Body                                              |
|--------|---------------------|----------------------------------------------------|
| POST   | /api/auth/signup    | `{name, email, password, educationLevel}`          |
| POST   | /api/auth/login     | `{email, password}`                                |

### Mock Tests
| Method | Endpoint                      | Body                                              |
|--------|--------------------------------|----------------------------------------------------|
| GET    | /api/categories?level=ITI     | —                                                  |
| GET    | /api/categories/{id}/tests    | —                                                  |
| GET    | /api/tests/{id}/questions     | —                                                  |
| POST   | /api/attempts/start           | `{userId, testId}`                                 |
| POST   | /api/attempts/submit          | `{attemptId, answers:[{questionId, selectedOptionId}]}` |

### Shop
| Method | Endpoint                              | Body                                                        |
|--------|------------------------------------------|----------------------------------------------------------------|
| GET    | /api/shop/categories                   | —                                                              |
| GET    | /api/shop/products?categoryId=&search= | —                                                              |
| GET    | /api/shop/sellers/{sellerId}/products  | —                                                              |
| POST   | /api/shop/products                     | `{sellerId, categoryId, title, description, price, stockQuantity, conditionType, imageUrl}` |
| DELETE | /api/shop/products/{id}?sellerId=      | —                                                              |
| POST   | /api/shop/orders/checkout              | `{buyerId, shippingAddress, items:[{productId, quantity}]}`   |
| GET    | /api/shop/orders/buyer/{buyerId}       | —                                                              |
| GET    | /api/shop/wallet/{userId}              | —                                                              |
| POST   | /api/shop/wallet/withdraw              | `{userId, amount}`                                             |

## What's NOT in this slice
- Real payment gateway integration (orders place instantly, no card/UPI capture)
- Admin panel for adding tests/questions through UI (currently done via SQL)
- JWT-based session security (current login is simple, no token expiry/refresh)
- Order status updates (shipped/delivered) — orders default to `PLACED`
- Product image upload (currently a URL field; no file storage)

Ask me to build any of these next and I'll wire them into this same project.
